package com.example.productsreenapp.ui

import androidx.compose.runtime.Composable

@Composable
fun getProduct(){

}