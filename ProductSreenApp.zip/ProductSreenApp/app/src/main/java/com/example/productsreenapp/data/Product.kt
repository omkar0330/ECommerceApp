package com.example.productsreenapp.data

data class Product(
    val title: String,
    val subtitle: String,
    val price: String,
    val imageUrl: String,
    val sku: String,
    val colors: List<String>,
    val description: String
)
