package com.example.productsreenapp.data

import com.google.firebase.appdistribution.gradle.ApiService
import com.example.productsreenapp.network.APIService

import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory

object RetrofitInstance {
    val api: ApiService by lazy {
        Retrofit.Builder()
            .baseUrl("https://klinq.com/rest/V1/")
            .addConverterFactory(GsonConverterFactory.create())
            .build()
            .create(ApiService::class.java)
    }
}