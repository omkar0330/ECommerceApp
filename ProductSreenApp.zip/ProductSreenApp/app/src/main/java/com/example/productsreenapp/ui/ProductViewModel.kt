package com.example.productsreenapp.ui

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.productsreenapp.data.Product
import com.example.productsreenapp.data.RetrofitInstance
import kotlinx.coroutines.launch

class ProductViewModel : ViewModel() {
    var isLoading by mutableStateOf(true)
    var errorMessage by mutableStateOf<String?>(null)
    var product by mutableStateOf<Product?>(null)
        private set

    init {
        getProductDetail()
    }

    private fun getProductDetail() {
        viewModelScope.launch {
            isLoading = true
            try {
                product = RetrofitInstance.api.getProduct()
                errorMessage = null
            } catch (e: Exception) {
                errorMessage = e.localizedMessage
            } finally {
                isLoading = false
            }
        }

    }
}