package com.example.productsreenapp.network

import com.example.productsreenapp.data.Product
import retrofit2.http.GET

interface APIService {
    @GET("productdetails/6701/253620?lang=en&store=KWD/")
    suspend fun getProduct()
}