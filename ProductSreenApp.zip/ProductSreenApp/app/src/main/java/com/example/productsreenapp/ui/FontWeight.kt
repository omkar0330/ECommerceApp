package com.example.productsreenapp.ui

class FontWeight {
    companion object {
        val Medium: FontWeight?
            get() {
                TODO()
            }
        val Bold: FontWeight?
            get() {
                TODO()
            }
    }

}
